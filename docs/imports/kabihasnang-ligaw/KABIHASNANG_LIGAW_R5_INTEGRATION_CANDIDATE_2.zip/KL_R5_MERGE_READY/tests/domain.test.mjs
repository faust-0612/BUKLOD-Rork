import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
// TS source converted for self-contained smoke tests without dependencies
const src=fs.readFileSync(new URL('../src/kabihasnang-ligaw/domain.ts',import.meta.url),'utf8');
const js=src.replace(/export type Episode = .*?;\n/,'').replace(/export type Completion = .*?;\n/,'').replace(/:Episode/g,'').replace(/:Date/g,'').replace(/:string\[\]/g,'').replace(/:string/g,'').replace(/:boolean/g,'').replace(/:number/g,'').replace(/:Set<string>/g,'').replace(/:string\[\]/g,'').replace(/:boolean/g,'').replace(/export /g,'').replace(/:string\)/g,')').replace(/:boolean\)/g,')').replace(/:Date\)/g,')').replace(/:string,/g,',').replace(/:boolean,/g,',');
const api=Function(js+';return {isReleased,releaseAtPht,seasonCompleted,rewardProposal,episodeRewardKey};')();
const e={id:'ep1',seasonId:'s1',number:1,title:'Test',author:'Author',approved:true,assetsVerified:true,paused:false,seasonPaused:false,releaseAt:'2026-10-20T22:00:00.000Z'};
test('6 AM Manila UTC mapping',()=>assert.equal(api.releaseAtPht('2026-10-21'),'2026-10-20T22:00:00.000Z'));
test('not early',()=>assert.equal(api.isReleased(e,new Date('2026-10-20T21:59:59Z')),false));
test('released at exact boundary',()=>assert.equal(api.isReleased(e,new Date('2026-10-20T22:00:00Z')),true));
test('paused blocks release',()=>assert.equal(api.isReleased({...e,paused:true},new Date('2026-10-21')),false));
test('unapproved blocks release',()=>assert.equal(api.isReleased({...e,approved:false},new Date('2026-10-21')),false));
test('invalid assets block release',()=>assert.equal(api.isReleased({...e,assetsVerified:false},new Date('2026-10-21')),false));
test('replay cannot reward',()=>assert.equal(api.rewardProposal(e,new Date('2026-10-21'),'u1',true,true),null));
test('engagement required',()=>assert.equal(api.rewardProposal(e,new Date('2026-10-21'),'u1',false,false),null));
test('2 points once candidate',()=>assert.equal(api.rewardProposal(e,new Date('2026-10-21'),'u1',false,true).points,2));
test('season complete requires all',()=>{assert.equal(api.seasonCompleted(['a','b'],new Set(['a'])),false);assert.equal(api.seasonCompleted(['a','b'],new Set(['a','b'])),true)});
