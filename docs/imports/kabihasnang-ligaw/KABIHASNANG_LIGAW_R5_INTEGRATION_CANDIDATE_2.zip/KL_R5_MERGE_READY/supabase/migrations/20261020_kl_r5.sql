-- KABIHASNANG LIGAW R5 - STAGING ONLY. DO NOT APPLY TO PRODUCTION WITHOUT SCHEMA REVIEW.
create schema if not exists kl;
create table if not exists kl.seasons (id uuid primary key default gen_random_uuid(), title text not null, paused boolean not null default true, created_at timestamptz not null default now());
create table if not exists kl.episodes (id uuid primary key default gen_random_uuid(), season_id uuid not null references kl.seasons(id), episode_number int not null check(episode_number>0), title text not null, author text not null, content jsonb not null default '[]'::jsonb, asset_manifest jsonb not null default '[]'::jsonb, content_sha256 text, editorial_approved_at timestamptz, assets_verified_at timestamptz, release_at timestamptz, paused boolean not null default true, created_at timestamptz not null default now(), unique(season_id,episode_number), check (jsonb_typeof(content)='array'), check(jsonb_typeof(asset_manifest)='array'));
create table if not exists kl.progress (user_id uuid not null, episode_id uuid not null references kl.episodes(id), last_block int not null default 0, updated_at timestamptz not null default now(), primary key(user_id,episode_id));
create table if not exists kl.completions (user_id uuid not null, episode_id uuid not null references kl.episodes(id), completed_at timestamptz not null default now(), primary key(user_id,episode_id));
create table if not exists kl.reward_outbox (id uuid primary key default gen_random_uuid(), user_id uuid not null, reward_key text not null, points int not null check(points in (2,10)), status text not null default 'pending' check(status in ('pending','processing','awarded','held','failed')), ledger_reference text, created_at timestamptz not null default now(), unique(user_id,reward_key));
create table if not exists kl.audit (id bigint generated always as identity primary key, actor uuid, action text not null, subject_id uuid, details jsonb not null default '{}'::jsonb, created_at timestamptz not null default now());
create table if not exists kl.glossary (id uuid primary key default gen_random_uuid(), term text not null unique, category text not null, definition text not null, reveal_episode_id uuid references kl.episodes(id));
create index if not exists kl_episode_schedule_idx on kl.episodes(release_at) where editorial_approved_at is not null and assets_verified_at is not null;
-- Restrict schema from client roles. Access only via separately reviewed authenticated RPC/API.
revoke all on schema kl from public, anon, authenticated;
revoke all on all tables in schema kl from public, anon, authenticated;
alter default privileges in schema kl revoke all on tables from public, anon, authenticated;
alter table kl.seasons enable row level security;
alter table kl.episodes enable row level security;
alter table kl.progress enable row level security;
alter table kl.completions enable row level security;
alter table kl.reward_outbox enable row level security;
alter table kl.audit enable row level security;
alter table kl.glossary enable row level security;
-- No policies deliberately: fail closed. Review existing auth/ledger interfaces before wiring.
create or replace function kl.is_episode_available(p_episode uuid, p_now timestamptz default now()) returns boolean language sql stable security invoker set search_path = kl, pg_temp as $$
select exists(select 1 from kl.episodes e join kl.seasons s on s.id=e.season_id where e.id=p_episode and not e.paused and not s.paused and e.editorial_approved_at is not null and e.assets_verified_at is not null and e.release_at <= p_now);
$$;
revoke all on function kl.is_episode_available(uuid,timestamptz) from public, anon, authenticated;
