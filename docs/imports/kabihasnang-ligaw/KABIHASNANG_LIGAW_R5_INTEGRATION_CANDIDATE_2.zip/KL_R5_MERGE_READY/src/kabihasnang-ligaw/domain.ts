/** Standalone pure domain logic. No writes to BUKLOD ledger or network. */
export type Episode = {id:string;seasonId:string;number:number;title:string;author:string;approved:boolean;assetsVerified:boolean;paused:boolean;seasonPaused:boolean;releaseAt:string};
export type Completion = {userId:string;episodeId:string;eligible:boolean};
export const TIMEZONE = 'Asia/Manila';
export const EPISODE_POINTS = 2;
export const SEASON_POINTS = 10;
export function isReleased(e:Episode,now:Date):boolean {const t=Date.parse(e.releaseAt);return Number.isFinite(t)&&e.approved&&e.assetsVerified&&!e.paused&&!e.seasonPaused&&t<=now.getTime();}
/** Philippine Standard Time UTC+08:00; Philippines does not currently use DST. */
export function releaseAtPht(dateYYYYMMDD:string):string {if(!/^\d{4}-\d{2}-\d{2}$/.test(dateYYYYMMDD))throw Error('Invalid release date');const t=new Date(dateYYYYMMDD+'T06:00:00+08:00');if(Number.isNaN(t.getTime())||new Date(dateYYYYMMDD+'T00:00:00Z').toISOString().slice(0,10)!==dateYYYYMMDD)throw Error('Invalid release date');return t.toISOString();}
export const episodeRewardKey=(episodeId:string)=>`kl:episode:${episodeId}`;
export const seasonRewardKey=(seasonId:string)=>`kl:season:${seasonId}`;
export function seasonCompleted(requiredEpisodeIds:string[],completedIds:Set<string>):boolean {return requiredEpisodeIds.length>0&&requiredEpisodeIds.every(id=>completedIds.has(id));}
export function rewardProposal(e:Episode, now:Date, userId:string, previouslyCompleted:boolean, validatedEngagement:boolean){if(!userId||!isReleased(e,now)||previouslyCompleted||!validatedEngagement)return null;return {userId,episodeId:e.id,points:EPISODE_POINTS,key:episodeRewardKey(e.id)};}
