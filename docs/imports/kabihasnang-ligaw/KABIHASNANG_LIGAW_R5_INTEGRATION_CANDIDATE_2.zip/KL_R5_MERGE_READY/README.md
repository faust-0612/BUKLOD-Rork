# Kabihasnang Ligaw R5 — Isolated integration candidate

**Status: PARTIAL MERGE CANDIDATE / NOT SAFE TO MERGE YET.** No production writes or OTA. This is a conservative, isolated code-and-schema foundation, **not** a complete working publishing service or app screen.

## Included
- `src/kabihasnang-ligaw/domain.ts`: Manila 06:00 schedule conversion, approved+assets+unpaused release gates, reward proposal logic, season completion checks.
- `src/kabihasnang-ligaw/content.ts`: block content contracts and sample episode.
- `supabase/migrations/20261020_kl_r5.sql`: fail-closed draft schema, no client grants, no automatic live reward posting.
- `tests/domain.test.mjs`: 10 passing smoke tests using Node 22, no npm installation.
- `docs/ARCHITECTURE_R5.md`: approved architectural spec.

## Merge blockers (must be resolved before production)
1. Verify latest cumulative production OTA/DEV and installed V28 runtime against the repository; default branch cannot be presumed authoritative.
2. Review actual Supabase auth, ledger, points awarding API, RLS and existing character service; **do not apply migration to live project** yet. The schema is intentionally locked to clients.
3. Implement and test authenticated server RPCs for editorial approval, scheduled read access, transactional idempotent completion + reward ledger posting and season bonus. Unique reward outbox alone is not an award.
4. Build React Native screen integration with BUKLOD navigation, actual media assets, audio focus/DZAS coordination, offline loading, glossary spoiler gates, admin controls, alerts, and performance checks.
5. Add staging end-to-end tests including simultaneous completion, 06:00 Manila boundary, future-content access, read-only permissions, reward replay and offline reconciliation.
6. Freeze reviewed RC diff and explicitly authorize any production deployment separately.

## Smoke test
`node --test tests/domain.test.mjs`

## Rules
Approved: one editorially approved episode daily 06:00 Asia/Manila, +2 points once per valid episode, +10 points once per completed season, separate Story Journey, preserve existing Character Points ledger, no deployment yet. Keep images scene-specific, realistic and uncluttered; magic/mystery rather than battle, original world architecture, author credit and optional melodic audio.
